package com.example.paymentt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
